# python-beat-detector
Real-time detection of beats for audio, calculates BPM and flashes LED strip in time with music.
